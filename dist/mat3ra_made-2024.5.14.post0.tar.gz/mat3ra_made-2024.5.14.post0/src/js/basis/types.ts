export type Coordinate = [number, number, number];
