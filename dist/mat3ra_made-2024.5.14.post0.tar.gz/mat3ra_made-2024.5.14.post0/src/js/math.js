// TODO: adjust the imports and remove the need for re-exporting
import { math as codeJSMath } from "@mat3ra/code/dist/js/math";

export default {
    ...codeJSMath,
};
