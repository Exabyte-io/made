import { AnyObject } from "@mat3ra/code/dist/js/entity/in_memory";
import { MaterialSchema } from "@mat3ra/esse/dist/js/types";

export type MaterialJSON = MaterialSchema & AnyObject;
