import { AnyObject } from "@mat3ra/esse/dist/js/esse/types";
import { MaterialSchema } from "@mat3ra/esse/dist/js/types";

export type MaterialJSON = MaterialSchema & AnyObject;
